
import Database.FileOperations;
import Model.InvoiceHeader;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author mbp
 */
public class InvoiceGenerator {

    public static void main(String[] args) {
        ArrayList<InvoiceHeader> list = FileOperations.readFile();
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
    }
}
