package controller;


import Database.FileOperations;
import Database.FileOperations1;
import Model.InvoiceHeader;
import Model.InvoiceLine;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Control {
    
  public static ArrayList<InvoiceHeader>  list=new ArrayList();

   public static void removeInvoice(String number) {
         
			for (int i = 0; i < list.size(); i++) {
				InvoiceHeader member = (InvoiceHeader) list.get(i);
				if (member.getInvoiceNumber().equalsIgnoreCase(number))
					list.remove(i);
			}
			
    
    }
   public static ArrayList<InvoiceHeader> load(){
        if(list.size()==0){
            list = FileOperations.readFile();
        }
      
      return list;
    }
    public static void save(){
      FileOperations.saveFile(list);
       
       ArrayList<InvoiceLine> inv=new  ArrayList();
        for(int i=0;i<list.size();i++){
            inv.addAll(list.get(i).getItems());
        }
       FileOperations1.saveFile(inv);
      
    }
    public  static ArrayList<InvoiceLine> getInvoiceLine(String number){
     for (int i = 0; i < list.size(); i++) {
				InvoiceHeader member = (InvoiceHeader) list.get(i);
				if (member.getInvoiceNumber().equalsIgnoreCase(number))
					return member.getItems();
			}
     return null;
    }
      public    static InvoiceHeader getInvoiceHeader(String number){
     for (int i = 0; i < list.size(); i++) {
				InvoiceHeader member = (InvoiceHeader) list.get(i);
				if (member.getInvoiceNumber().equalsIgnoreCase(number))
					return member;
			}
     return null;
    }
     public static void updateInvoiceHeader(InvoiceHeader ms){
       
       
		for (int i = 0; i < list.size(); i++) {
			
			if (list.get(i).getInvoiceNumber().equals(ms.getInvoiceNumber())) {
				list.set(i, ms);
                                System.out.println(ms.getCustomer());
		}
		}
		
   }
       public static void addInvoice(InvoiceHeader ms){
       
       
		list.add(ms);
		
   }
       
  
}
