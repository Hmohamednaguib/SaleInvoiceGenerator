package Database;

import Model.InvoiceLine;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class FileOperations1 {

    public static final String DB_FILENAME = "InvoiceLine.csv";
    public static final String SEPARATOR = ",";

    /**
     * Database Function *
     */
    /**
     * Read and Write from database
     *
     * @return e*
     */
    public static ArrayList<InvoiceLine> readFile() {
        ArrayList<String> stringArray;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        ArrayList<InvoiceLine> alr = new ArrayList<>();
        try {
            stringArray = DatabaseIO.read(DB_FILENAME);

            for (int i = 0; i < stringArray.size(); i++) {
                String st = (String) stringArray.get(i);
                StringTokenizer star = new StringTokenizer(st, SEPARATOR);

                String no = star.nextToken().trim();
                String name = star.nextToken().trim();

                int price = Integer.parseInt(star.nextToken().trim());
                int count = Integer.parseInt(star.nextToken().trim());

                InvoiceLine stud = new InvoiceLine(no, name,price, count);
                alr.add(stud);
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }

        return alr;
    }

    /**
     * Save the list in database
     *
     * @param al
     */
    public static void saveFile(List<InvoiceLine> al) {

        List<String> alw = new ArrayList<>();

        for (int i = 0; i < al.size(); i++) {
            InvoiceLine stud = (InvoiceLine) al.get(i);
            StringBuilder st = new StringBuilder();
            st.append(stud.getInvoiceNumber().trim());
            st.append(SEPARATOR);
            st.append(stud.getName());
            st.append(SEPARATOR);
            st.append(stud.getPrice());
             st.append(SEPARATOR);
            st.append(stud.getCount());
            
            alw.add(st.toString());
        }

        try {
            DatabaseIO.write(DB_FILENAME, alw);
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

}
