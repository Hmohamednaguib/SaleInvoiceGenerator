package Model;

import java.time.LocalDate;
import java.util.ArrayList;

public class InvoiceHeader {

    private String invoiceNumber;
    private LocalDate date;
    private ArrayList<InvoiceLine> items;
    String Customer;

    public InvoiceHeader(String invoiceNumber, LocalDate date, String customer) {
        this.invoiceNumber = invoiceNumber;
        this.date = date;
        items = new ArrayList<InvoiceLine>();

        this.Customer = customer;

    }
    public InvoiceHeader(){
          items = new ArrayList<InvoiceLine>();
    }

    public String getCustomer() {
        return Customer;
    }

    public void setCustomer(String Customer) {
        this.Customer = Customer;
    }

    /**
     * @return the invoiceNumber
     */
    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    /**
     * @param invoiceNumber the invoiceNumber to set
     */
    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    /**
     * @return the date
     */
    public LocalDate getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(LocalDate date) {
        this.date = date;
    }

    /**
     * @return the items
     */
    public ArrayList<InvoiceLine> getItems() {
        return items;
    }

    /**
     * @param items the items to set
     */
    public void setItems(ArrayList<InvoiceLine> items) {
        this.items = items;
    }

    public String toString() {
     String str="\nInvoice Number: "+this.invoiceNumber+"{\n";
     for (int i = 0; i < this.items.size(); i++) {
			str=str+this.items.get(i)+"\n";
			}
     str=str+"}";
     return str;

    }
}
