package org.example;

import Database.FileOperations;
import Model.InvoiceHeader;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<InvoiceHeader> list = FileOperations.readFile();
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
    }
}